from django.apps import AppConfig


class NotekeeperConfig(AppConfig):
    name = 'notekeeper'
